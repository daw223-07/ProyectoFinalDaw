import { Person } from "./person";

export interface Credit{
    id: string;
    cast: Person[];
}