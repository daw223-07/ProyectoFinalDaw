export const environment = {
    production: true,
    apiUrl: 'https://api.themoviedb.org/3/',
    api_key: '?api_key=f36cd175c67196eaa73c5aab30363e83',
    
    language: "&language=es",
    region: "&region=es",

    session_id: '&session_id=',
    account: 'account/',

    query: "&query=",
    page: "&page=",
    with_genres: "&with_genres=",
    
    movie_id: "&movie_id=",

    confirm: "&confirm=",

    srcImage: "https://image.tmdb.org/t/p/original",

    urlTrailerYouTube: "https://www.youtube.com/watch?v="
};